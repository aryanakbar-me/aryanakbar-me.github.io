import React, { useEffect, useState } from 'react';
import { Shield, Terminal, Code, Mail, Github, Linkedin, ExternalLink, ChevronDown, Lock, Zap, Search, Bug, Eye, FileText, Users } from 'lucide-react';

interface MatrixChar {
  char: string;
  x: number;
  y: number;
  speed: number;
}

const MatrixRain: React.FC = () => {
  const [chars, setChars] = useState<MatrixChar[]>([]);

  useEffect(() => {
    const characters = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const newChars: MatrixChar[] = [];
    
    for (let i = 0; i < 50; i++) {
      newChars.push({
        char: characters[Math.floor(Math.random() * characters.length)],
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        speed: Math.random() * 2 + 1
      });
    }
    
    setChars(newChars);

    const interval = setInterval(() => {
      setChars(prev => prev.map(char => ({
        ...char,
        y: char.y > window.innerHeight ? -20 : char.y + char.speed,
        char: Math.random() > 0.95 ? characters[Math.floor(Math.random() * characters.length)] : char.char
      })));
    }, 50);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none opacity-10 overflow-hidden">
      {chars.map((char, index) => (
        <div
          key={index}
          className="absolute text-green-400 font-mono text-sm"
          style={{
            left: char.x,
            top: char.y,
            transform: 'translateZ(0)'
          }}
        >
          {char.char}
        </div>
      ))}
    </div>
  );
};

const TerminalCard: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-black border border-green-400/30 rounded-lg p-6 hover:border-green-400 hover:shadow-lg hover:shadow-green-400/20 transition-all duration-300 group ${className}`}>
    <div className="flex items-center gap-2 mb-4">
      <div className="w-3 h-3 rounded-full bg-red-500"></div>
      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
      <div className="w-3 h-3 rounded-full bg-green-500"></div>
    </div>
    {children}
  </div>
);

const GlowButton: React.FC<{ children: React.ReactNode; onClick?: () => void; className?: string }> = ({ children, onClick, className = '' }) => (
  <button 
    onClick={onClick}
    className={`bg-black border border-green-400 text-green-400 px-6 py-3 rounded-lg hover:bg-green-400 hover:text-black transition-all duration-300 hover:shadow-lg hover:shadow-green-400/50 ${className}`}
  >
    {children}
  </button>
);

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const projects = [
    {
      name: 'SecurityX',
      description: 'Android app for digital safety — app monitoring, privacy protection, network scanning, malicious domain blocking.',
      icon: <Shield className="w-6 h-6" />,
      tech: ['Android', 'Kotlin', 'Security']
    },
    {
      name: 'HidayahGuard',
      description: 'A family-friendly AI-powered safe browsing tool designed to protect underage boys and girls online by filtering harmful or inappropriate content. It uses advanced AI to block malicious websites, explicit material, and risky domains, helping parents keep kids safe in the digital world.',
      icon: <Shield className="w-6 h-6" />,
      tech: ['AI', 'Content Filtering', 'Family Safety']
    },
    {
      name: 'Cyber Defender',
      description: 'Defensive platform for home & SME networks — real-time traffic monitoring, IDS, threat intelligence integration, auto-response.',
      icon: <Lock className="w-6 h-6" />,
      tech: ['Network Security', 'IDS', 'Python']
    },
    {
      name: 'Industrial Cyber Shield',
      description: 'Hardening tool for OT/ICS — secure industrial networks, detect protocol abuse, defend SCADA/PLC, comply with NERC CIP, IEC 62443, ISO 27001.',
      icon: <Zap className="w-6 h-6" />,
      tech: ['Industrial Security', 'SCADA', 'Compliance']
    },
    {
      name: 'NetSpector',
      description: 'Recon & advanced packet analysis tool for network visibility.',
      icon: <Search className="w-6 h-6" />,
      tech: ['Network Analysis', 'Reconnaissance', 'Python']
    },
    {
      name: 'SHRX',
      description: 'High-speed subdomain enumeration & recon automation for bug bounty hunters.',
      icon: <Terminal className="w-6 h-6" />,
      tech: ['Bug Bounty', 'Automation', 'Bash']
    },
    {
      name: 'OSINT Searcher',
      description: 'Android OSINT tool for open-source intelligence gathering.',
      icon: <Eye className="w-6 h-6" />,
      tech: ['OSINT', 'Android', 'Kotlin']
    },
    {
      name: 'Ethical Phishing Simulation',
      description: 'Training tool for client awareness and security education.',
      icon: <Users className="w-6 h-6" />,
      tech: ['Training', 'Security Awareness', 'Python']
    },
    {
      name: 'Secure File Transfer App',
      description: 'Encrypted data exchange platform for secure communications.',
      icon: <FileText className="w-6 h-6" />,
      tech: ['Encryption', 'Security', 'File Transfer']
    },
    {
      name: 'VulnHawk',
      description: 'AI-powered bug bounty automation tool — Python, Bash, local LLMs, fully controlled via Cursor AI Agent. (In Development)',
      icon: <Bug className="w-6 h-6" />,
      tech: ['AI', 'Bug Bounty', 'LLMs']
    }
  ];

  const skills = [
    'Penetration Testing', 'OSINT & Threat Intelligence', 'Python', 'Bash', 'Dart/Flutter',
    'Kotlin', 'JavaScript', 'Burp Suite Pro', 'Linux', 'Wireshark', 'Nmap', 'Metasploit',
    'Sqlmap', 'Nessus', 'Nikto', 'Nuclei', 'John', 'Hydra', 'Yersinia', 'WPscan',
    'Network Security', 'API Security', 'Mobile Security', 'Web Security'
  ];

  const certifications = [
    'Ethical Hacking Essentials (EC-Council)',
    'Certified Network Pentester (The SecOps Group)',
    'Certified Information Systems Security Professional (Cybrary)',
    'Certified Network Security Professional (CNSP) — In Progress'
  ];

  return (
    <div className="min-h-screen bg-black text-green-400 font-mono relative overflow-x-hidden">
      <MatrixRain />
      
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/90 backdrop-blur-sm border-b border-green-400/30 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Terminal className="w-6 h-6 text-green-400" />
              <span className="text-xl font-bold">AryanAkbar@CyberSecOrg:~$<span className="cursor"></span></span>
            </div>
            
            <div className="hidden md:flex space-x-8">
              {['about', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="hover:text-green-300 transition-colors duration-200 capitalize"
                >
                  {item}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              <div className="w-6 h-6 flex flex-col justify-center space-y-1">
                <span className="block w-full h-0.5 bg-green-400 transition-all duration-200"></span>
                <span className="block w-full h-0.5 bg-green-400 transition-all duration-200"></span>
                <span className="block w-full h-0.5 bg-green-400 transition-all duration-200"></span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-green-400/30 bg-black">
            <div className="px-4 py-4 space-y-4">
              {['about', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="block w-full text-left hover:text-green-300 transition-colors duration-200 capitalize"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative pt-16">
        <div className="text-center z-10 max-w-4xl mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold mb-4 text-green-400 animate-pulse">
              ARYAN AKBAR
            </h1>
            <div className="text-lg md:text-xl text-green-300 mb-6 font-sans">
              Self-taught Cybersecurity Specialist & Penetration Tester
            </div>
            <div className="text-sm text-green-400/70 font-mono mb-8">
              root@aryanakbar:~$ ./init_security_specialist.sh<span className="cursor"></span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <GlowButton onClick={() => scrollToSection('projects')}>
              View Projects
            </GlowButton>
            <GlowButton onClick={() => scrollToSection('contact')}>
              Contact Me
            </GlowButton>
          </div>

          <div className="mt-12 animate-bounce">
            <ChevronDown className="w-8 h-8 mx-auto text-green-400" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <TerminalCard>
            <h2 className="text-3xl font-bold mb-6 text-green-400">
              $ cat about_me.txt
            </h2>
            <div className="text-green-300 font-sans space-y-4 leading-relaxed">
              <p>
                Hi, I'm Aryan Akbar, a self-taught cybersecurity specialist and penetration tester from Vehari, Punjab, Pakistan. I've discovered and reported real-world vulnerabilities to global companies like Amazon, OPPO, and Starbucks — all before finishing high school.
              </p>
              
              <div className="mt-8 p-4 border border-green-400/30 rounded-lg bg-black/50">
                <h3 className="text-xl font-bold text-green-400 mb-4">Future Plans</h3>
                <p className="text-green-300 font-sans">
                  Planning to move to Dresden, Germany, for Ausbildung in Fachinformatiker für Systemintegration — to deepen my system-level cybersecurity skills while living affordably and tapping into Europe's tech ecosystem.
                </p>
              </div>
            </div>
          </TerminalCard>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-12 text-green-400 text-center">
            $ ls -la projects/
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {projects.map((project, index) => (
              <TerminalCard key={index}>
                <div className="flex items-center gap-3 mb-4">
                  {project.icon}
                  <h3 className="text-xl font-bold text-green-400">{project.name}</h3>
                </div>
                <p className="text-green-300 font-sans mb-4 text-sm leading-relaxed">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-2 py-1 text-xs bg-green-400/20 text-green-400 rounded border border-green-400/30"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </TerminalCard>
            ))}
          </div>

          {/* Bug Bounty Reports */}
          <TerminalCard>
            <h3 className="text-2xl font-bold mb-6 text-green-400">
              $ cat bug_bounty_reports.log
            </h3>
            <div className="space-y-4 text-green-300 font-sans">
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 mt-1 text-green-400" />
                <div>
                  <h4 className="font-bold text-green-400">Amazon Security Report</h4>
                  <p className="text-sm">Critical vulnerability discovered, with detailed remediation recommendations.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 mt-1 text-green-400" />
                <div>
                  <h4 className="font-bold text-green-400">OPPO Security Report</h4>
                  <p className="text-sm">API security flaws, authentication bypass vulnerabilities identified.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 mt-1 text-green-400" />
                <div>
                  <h4 className="font-bold text-green-400">Starbucks Bug Bounty Report</h4>
                  <p className="text-sm">High-impact vulnerability disclosed through responsible disclosure.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 mt-1 text-green-400" />
                <div>
                  <h4 className="font-bold text-green-400">Private Client Assessments</h4>
                  <p className="text-sm">Conducted pentesting, vulnerability assessments, and delivered comprehensive remediation plans.</p>
                </div>
              </div>
            </div>
          </TerminalCard>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Technical Skills */}
            <TerminalCard>
              <h3 className="text-2xl font-bold mb-6 text-green-400">
                $ cat technical_skills.txt
              </h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <span 
                    key={index}
                    className="px-3 py-1 text-sm bg-green-400/20 text-green-400 rounded border border-green-400/30 hover:bg-green-400/30 transition-colors duration-200"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </TerminalCard>

            {/* Certifications & Education */}
            <TerminalCard>
              <h3 className="text-2xl font-bold mb-6 text-green-400">
                $ cat certifications.txt
              </h3>
              <div className="space-y-3 mb-6">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-green-300 font-sans text-sm">{cert}</span>
                  </div>
                ))}
              </div>
              
              <div className="pt-4 border-t border-green-400/30">
                <h4 className="text-lg font-bold text-green-400 mb-3">Education & Training</h4>
                <div className="space-y-2 text-green-300 font-sans text-sm">
                  <p>• Matric (Computer Science) — Ongoing</p>
                  <p>• IBM, Cybrary, Stanford University — Cybersecurity & Systems courses</p>
                  <p>• EC-Council & Stanford modules (SQL Injection, DFE, NDE, Android Bug Hunting)</p>
                  <p>• Cybersecurity Compliance IBM certification</p>
                </div>
              </div>
            </TerminalCard>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 relative z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <TerminalCard>
            <h2 className="text-3xl font-bold mb-8 text-green-400 text-center">
              $ ./contact_me.sh
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Contact Form */}
              <div>
                <h3 className="text-xl font-bold mb-4 text-green-400">Send Secure Message</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-green-400 mb-2">Name</label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 bg-black border border-green-400/30 rounded-lg text-green-300 focus:border-green-400 focus:ring-1 focus:ring-green-400 outline-none transition-colors duration-200"
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-green-400 mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full px-3 py-2 bg-black border border-green-400/30 rounded-lg text-green-300 focus:border-green-400 focus:ring-1 focus:ring-green-400 outline-none transition-colors duration-200"
                      placeholder="Enter your email"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-green-400 mb-2">Message</label>
                    <textarea
                      rows={4}
                      className="w-full px-3 py-2 bg-black border border-green-400/30 rounded-lg text-green-300 focus:border-green-400 focus:ring-1 focus:ring-green-400 outline-none transition-colors duration-200"
                      placeholder="Your message..."
                    ></textarea>
                  </div>
                  <GlowButton className="w-full">
                    Send Message
                  </GlowButton>
                </form>
              </div>

              {/* Contact Links */}
              <div>
                <h3 className="text-xl font-bold mb-4 text-green-400">Connect</h3>
                <div className="space-y-4">
                  <a 
                    href="mailto:contact.aryanakbar@gmail.com" 
                    className="flex items-center gap-3 p-3 border border-green-400/30 rounded-lg hover:border-green-400 hover:bg-green-400/10 transition-all duration-200"
                  >
                    <Mail className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-sans">contact.aryanakbar@gmail.com</span>
                  </a>
                  
                  <a 
                    href="tel:+92401668965" 
                    className="flex items-center gap-3 p-3 border border-green-400/30 rounded-lg hover:border-green-400 hover:bg-green-400/10 transition-all duration-200"
                  >
                    <Terminal className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-sans">+92 401 668 965</span>
                  </a>
                  
                  <a 
                    href="https://instagram.com/cyber_expert_aryan" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 border border-green-400/30 rounded-lg hover:border-green-400 hover:bg-green-400/10 transition-all duration-200"
                  >
                    <ExternalLink className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-sans">@cyber_expert_aryan (Instagram)</span>
                  </a>
                  
                  <a 
                    href="https://facebook.com/aryanakbarjoiya" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 border border-green-400/30 rounded-lg hover:border-green-400 hover:bg-green-400/10 transition-all duration-200"
                  >
                    <Users className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 font-sans">Aryan Akbar Joiya (Facebook)</span>
                  </a>
                </div>

                <div className="mt-6 p-4 border border-green-400/30 rounded-lg bg-green-400/5">
                  <h4 className="text-lg font-bold text-green-400 mb-2">Security Notice</h4>
                  <p className="text-green-300 font-sans text-sm">
                    For sensitive communications, please use encrypted channels. PGP key available upon request.
                  </p>
                </div>
              </div>
            </div>
          </TerminalCard>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-green-400/30 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-green-400/70 font-mono">
            <p>© 2025 Aryan Akbar — All Rights Reserved</p>
            <p className="mt-2 text-sm">
              root@aryanakbar:~$ echo "Securing the digital world, one vulnerability at a time"<span className="cursor"></span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;